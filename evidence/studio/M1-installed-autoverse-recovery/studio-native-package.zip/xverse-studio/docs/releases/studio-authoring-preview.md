# Studio authoring and retention checkpoint

Application code: `a207ad6d9dec853a8f3558b398985dd55ef5bb2f`.
Branch: `implement/studio-m0-m4`. Draft PR: https://github.com/The-Xverse/xverse-studio/pull/1.
Status: runnable native Linux reference; no M0–M4 milestone or Studio 1.0 acceptance claim.

The System workflows now include neutral Device/Sensor/Actuator/Model authoring, independent roles
and capabilities, explicit deployment-variant bindings, selected-declaration source navigation,
empty draft recovery, Scenario conditions/stimulus/fault/observer/metric intent, and explicit
project/run/artifact-registration retention. Unsupported reference topology or schedule edits block
execution. Artifact removal is registration metadata only. Private complete backup/restore preserves
canonical source, snapshots and journals, clears restored browser sessions and never replays work.

Twenty-one component tasks are complete with cited evidence: T003, T006, T013, T017, T022, T024, T036,
T041, T042, T044, T050, T085, T086, T087, T092, T020, T094, T018, T019, T029, T030. This does not waive their milestone acceptance gates.

## Executed verification

- Native Ubuntu 22.04.5 x86_64, Python 3.13.13: **466 backend tests passed**, one existing dependency
  deprecation warning; recorded application/test source hashes unchanged during the run.
- Node 24.22.1, Chromium 156.0.8078.4: **21 Playwright checks passed**, no failures/skips/flakes.
  Sixteen are actual browser journeys; five are pure projection/display checks. The journeys include actual
  reference execution/reconnect/rerun/campaign controls, both required viewports, keyboard/focus,
  source isolation, dependency refusal, retention effects and external-byte inspection.
- After one warm-up, 30 repetitions: selection/inspector p95 **36.6 ms**; open/authoritative validation
  **1,100.4 ms**; first 200 history records from 50,000 canonical fixture events **929.8 ms**. Recorded
  history identities/integrity stayed unchanged. This fixture is not external simulator/device evidence.
- A fresh package provisioned offline from the prepared dependency cache, started natively, served
  its UI, persisted a project and compiled authoritatively. An initial restricted test PATH omitted
  the installed Python; that failed receipt is retained separately from the corrected successful run.
- Independent review findings were recorded before repairs, including dependency proof shape/bounds,
  observer/assertion references, deep edit handling, source/SQLite acquisition, directory continuity,
  and restore-marker ordering. Original findings and intermediate failures remain retained.

Evidence: `evidence/studio/release/linux-evidence-query-2026-10-25/`, the component review folders and
`traceability.json`. Counts overlap and are not added. Backend/application/test source remained unchanged during the final full-suite/browser checks.
Clean product commit 829d428 passed the fresh-package smoke. Earlier cohort and packaging findings
remain retained separately. Publication redactions retain raw receipts
privately on loop10 without changing verification outcomes or product source hashes.

## Remaining scope

Windows installation/testing stays blocked at user request. Secure file acquisition currently has
only an admitted Linux implementation; that owned Windows gap is separate from the upstream
Windows-invalid Git filename. No WSL/container substitute or verified Windows installation is claimed.

External Lite still needs an admitted effective-input/plan contract and permitted environment.
Feedback compilation, independent live industry providers, physical provider/device/permission,
clock/shutdown evidence and five first-time users remain blocked. Ready Linux work includes remaining restriction/slow-consumer fixtures, cursor resynchronization
and diagnostic explanation coverage. Readiness and trace-claim successor evidence is recorded below. M5 remains deferred.

## Launch and recovery

After the pinned Linux provisioning/build in `docs/user/getting-started.md`:

```text
.venv/bin/python -I -m xverse_studio.host.launcher --data-dir .studio-local/data --port 8876
```

Open http://127.0.0.1:8876 and read the one-use token locally from
`.studio-local/data/bootstrap.json`. Ctrl+C stops the native backend and requests owned cancellation;
browser closure does not own or terminate runs. Follow `docs/user/recovery.md` for stopped-root full
backup/restore, `docs/user/retention.md` for explicit deletion, and `docs/user/scenario-authoring.md`
for authored intent versus admitted execution. All local implementation artifacts remain on loop10.

## Readiness and trace-claim successor

Ten independent readiness facts, exact selected-provider limits/remediation and frozen plan inspection
now support informed admission. Backend fixes reject selected-provider substitution, unknown facts,
incompatible operation/XDL scope and blocked-snapshot campaign promotion, while resolving accepted
idempotent retries before mutable readmission. Revisioned external claims preserve exact optional
reported status and frozen model/Scenario/definition/evidence subjects. A reported external pass never
changes the actual assertion verdict. Review repairs isolate annotation editors/callbacks across runs
and route snapshot display through bounded canonical acquisition.

The final full backend cohort passed 393 tests after the display-reader repair; earlier predecessor
and focused reader/rerun receipts remain retained separately. The final browser candidate passed 15 checks, including ten actual
journeys, with source unchanged. Final 30-repetition p95 values: selection 29.5 ms, open/validation
590.4 ms, and recorded-fixture history 196.2 ms. Counts overlap and are not added. See
`evidence/studio/release/linux-readiness-claims-2026-10-25/` and independent component reviews.
No M0–M4 milestone is accepted from these Linux component results.

## Evidence-selection successor

Exact source/receipt selection, emitter/observer/element/field predicates, bounded whole-run facets,
context-bound paging and explicit omissions now support Results. Original clock, receipt, resolution
and value-unit metadata remain inspectable; zero/false are distinct from unavailable data. Concurrent
append acquisition, malformed proof, duplicate IDs and bad sequences have explicit reader outcomes.
Recorded fixture scope is preserved and filters never submit lifecycle commands.

The 466-backend/21-browser cohort above includes the independently reviewed new components. T028's
restriction/private-log and advancing-producer/slow-consumer fixtures and T026 expired-cursor resync
remain open. All broader native/live acceptance gates remain unchanged. See ADR-0010 and
`docs/user/results-filters.md` for the query, precision and browser behavior.
