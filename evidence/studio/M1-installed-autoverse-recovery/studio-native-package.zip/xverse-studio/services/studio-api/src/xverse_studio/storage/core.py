"""Transactional local metadata; immutable file revisions hold authored XDL."""

from __future__ import annotations
import contextlib
import hashlib
import json
from pathlib import Path
import sqlite3
import threading
import uuid


def uid(prefix=""):
    return prefix + str(uuid.uuid4())


def canonical(value):
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def digest(value):
    raw = value if isinstance(value, bytes) else canonical(value).encode()
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def atomic(path: Path, data: bytes):
    from xverse_studio.security.managed_io import atomic_write

    # The caller owns the managed destination. Acquire each native ancestor
    # without following links rather than reopening a previously checked name.
    atomic_write(Path("/"), path.absolute(), data)


def contained(root: Path, path: Path):
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Path escapes the managed workspace")
    return path


class Problem(Exception):
    def __init__(self, code, message, status=422, **details):
        self.code, self.message, self.status, self.details = (
            code,
            message,
            status,
            details,
        )
        super().__init__(message)


class Store:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.dbpath = self.root / "studio.sqlite"
        if self.dbpath.exists():
            # Inspect committed metadata before enabling WAL or writing schema.
            # The native launcher/maintenance root lock excludes another owner.
            with contextlib.closing(sqlite3.connect(self.dbpath.as_uri() + "?mode=ro", uri=True)) as db:
                version = db.execute("PRAGMA user_version").fetchone()[0]
                empty = not db.execute("SELECT 1 FROM sqlite_schema LIMIT 1").fetchone()
                if version != 1 and not (version == 0 and empty):
                    raise Problem("MIGRATION_REQUIRED",
                        "Existing metadata needs an explicit supported copy migration; keep the original root and backup.", 503)
        try:
            self.root.chmod(0o700)
        except OSError:
            pass
        self.lock = threading.RLock()
        self._rollback_hooks = {}
        with self.tx() as db:
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, 1):
                raise Problem(
                    "MIGRATION_REQUIRED",
                    "Unsupported database version; restore a supported backup.",
                    503,
                )
            db.execute(
                "CREATE TABLE IF NOT EXISTS records (kind TEXT NOT NULL, id TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(kind,id))"
            )
            db.execute(
                "CREATE TABLE IF NOT EXISTS idempotency (scope TEXT NOT NULL, key TEXT NOT NULL, fingerprint TEXT NOT NULL, result TEXT NOT NULL, PRIMARY KEY(scope,key))"
            )
            db.execute("PRAGMA user_version=1")

    @contextlib.contextmanager
    def tx(self):
        with self.lock:
            db = sqlite3.connect(self.dbpath, timeout=15)
            try:
                db.execute("PRAGMA journal_mode=WAL")
                db.execute("PRAGMA foreign_keys=ON")
                db.execute("BEGIN IMMEDIATE")
                self._rollback_hooks[id(db)] = []
                yield db
                db.commit()
            except BaseException:
                uncommitted = db.in_transaction
                db.rollback()
                if uncommitted:
                    for cleanup in reversed(self._rollback_hooks.get(id(db), [])):
                        cleanup()
                raise
            finally:
                self._rollback_hooks.pop(id(db), None)
                db.close()

    def on_rollback(self, db, cleanup):
        self._rollback_hooks[id(db)].append(cleanup)

    def get(self, kind, id, db=None):
        if db is None:
            with self.tx() as db:
                return self.get(kind, id, db)
        row = db.execute(
            "SELECT body FROM records WHERE kind=? AND id=?", (kind, id)
        ).fetchone()
        if row is None:
            raise Problem("NOT_FOUND", "Requested record was not found.", 404)
        return json.loads(row[0])

    def put(self, kind, id, body, db=None):
        if db is None:
            with self.tx() as db:
                return self.put(kind, id, body, db)
        db.execute(
            "INSERT INTO records VALUES(?,?,?) ON CONFLICT(kind,id) DO UPDATE SET body=excluded.body",
            (kind, id, canonical(body)),
        )
        return body

    def all(self, kind, db=None):
        if db is None:
            with self.tx() as db:
                return self.all(kind, db)
        return [
            json.loads(r[0])
            for r in db.execute(
                "SELECT body FROM records WHERE kind=? ORDER BY rowid DESC", (kind,)
            )
        ]

    def find(self, kind, field, value, db=None):
        """Records of one kind whose top-level JSON field equals value."""
        if db is None:
            with self.tx() as db:
                return self.find(kind, field, value, db)
        if not field.isidentifier():
            raise ValueError("field must be a plain identifier")
        return [
            json.loads(r[0])
            for r in db.execute(
                "SELECT body FROM records WHERE kind=? AND json_extract(body, ?)=? "
                "ORDER BY rowid DESC",
                (kind, "$." + field, value),
            )
        ]

    def idempotent(self, principal, route, key, payload, fn):
        if not key or len(key) > 128:
            raise Problem(
                "IDEMPOTENCY_REQUIRED",
                "Supply an Idempotency-Key of at most 128 characters.",
                428,
            )
        scope = principal + ":" + route
        fingerprint = digest(payload)
        with self.tx() as db:
            row = db.execute(
                "SELECT fingerprint,result FROM idempotency WHERE scope=? AND key=?",
                (scope, key),
            ).fetchone()
            if row:
                if row[0] != fingerprint:
                    raise Problem(
                        "IDEMPOTENCY_CONFLICT",
                        "This key already identifies a different request.",
                        409,
                    )
                return json.loads(row[1]), False
            result = fn(db)
            db.execute(
                "INSERT INTO idempotency VALUES(?,?,?,?)",
                (scope, key, fingerprint, canonical(result)),
            )
            return result, True
